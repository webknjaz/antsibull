required-and-default-attributes
===============================

Use only one of ``default`` or ``required`` with ``FieldAttribute``.

